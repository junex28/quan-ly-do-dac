dojo.provide("myModules.InfoWindow");

dojo.require("esri.InfoWindowBase");
dojo.require("dojo.fx");
/***************
 * MyInfoWindow
 ***************/
dojo.declare("myModules.InfoWindow", [ esri.InfoWindowBase ], {
 
 //number: width of infowindow
  width: 100,
  
  //number: height of infowindow
  height: 39,
 
  constructor: function(parameters) {
    dojo.mixin(this, parameters);
    


    
    dojo.addClass(this.domNode, "myInfoWindow");

    this._navigateButton = dojo.create("div", { "class": "navigate", title: "Navigate" }, this.domNode);
    this._title = dojo.create("div", { "class": "title" }, this.domNode);
    this._content = dojo.create("div", { "class": "content" }, this.domNode);

   // this._arrow = dojo.create("div",{"class":"upArrow"},this.domNode);
   
   
   this.resize(this.width, this.height);
 

    this._eventConnections = [
      dojo.connect(this._navigateButton, "onclick", this, function(){
        this.hide(); //hide the info window when the button is clicked 
        this.onNavigate(this._content);
      })
    ];

    // Hidden initially
    esri.hide(this.domNode);            
    this.isShowing = false;
  },
  
  /*****************************************
   * Override and implement methods defined  
   * by the base class: InfoWindowBase
   *****************************************/

  setMap: function(map) {
    // Run logic defined in the base class
    this.inherited(arguments);
    
     //  hide the info window when the user is focusing elsewhere.
    this._eventConnections.push(dojo.connect(map, "onPanStart", this, this.hide));
    this._eventConnections.push(dojo.connect(map, "onZoomStart", this, this.hide));
    //this._eventConnections.push(dojo.connect(map,"onClick",this,this.hide));
  },
  
  setTitle: function(title) {
    this.place(title, this._title);
  },
  
  setContent: function(content) {
   this._content = content;
   //this.place(content, this._content);
  
  },
  
  show: function(location) {
    // Is location specified in map coordinates?
    if (location.spatialReference) {
      location = this.map.toScreen(location);
    }
    
    // Position 10x10 pixels away from the 
    // requested location
    dojo.style(this.domNode, {
      left: (location.x + 5) + "px",
      top: (location.y + 5) + "px"
    });
    // Display
    esri.show(this.domNode);
    this.isShowing = true;
    this.onShow();
  },
  hide: function() {
    esri.hide(this.domNode);
    this.isShowing = false;
    this.onHide();
  },
  
  resize: function(width, height) {
    this.width = width;
    this.height = height;
    dojo.style(this._title, { width: width + "px", height: height + "px" });
    dojo.style(this._navigateButton, { left: (width -10 ) + "px", top: "-2px" });
  },
  
  /************************************
   * Defining some methods specific to
   * my info window
   ************************************/
    onNavigate: function (content) {
    //summary: When users clicks the navigate button
  },
  destroy: function() {
    dojo.forEach(this._eventConnections, dojo.disconnect);
    dojo.destroy(this.domNode);
    this._navigateButton = this._title = this._content = this._eventConnections = null;
  }
  
});