window[esri._dojoScopeName||"dojo"]._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dijit.form.nls.pt.Textarea"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dijit.form.nls.pt.Textarea");dojo._xdLoadFlattenedBundle("dijit.form", "Textarea", "pt", {"iframeEditTitle":"editar área","iframeFocusTitle":"editar quadro da área"});
}};});