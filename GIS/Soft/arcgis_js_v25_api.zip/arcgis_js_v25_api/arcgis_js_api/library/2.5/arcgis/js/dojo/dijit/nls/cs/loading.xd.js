window[esri._dojoScopeName||"dojo"]._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dijit.nls.cs.loading"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dijit.nls.cs.loading");dojo._xdLoadFlattenedBundle("dijit", "loading", "cs", {"loadingState":"Probíhá načítání...","errorState":"Omlouváme se, došlo k chybě"});
}};});