window[esri._dojoScopeName||"dojo"]._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dijit.nls.ar.common"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dijit.nls.ar.common");dojo._xdLoadFlattenedBundle("dijit", "common", "ar", {"buttonOk":"حسنا","buttonCancel":"الغاء","buttonSave":"حفظ","itemClose":"اغلاق"});
}};});