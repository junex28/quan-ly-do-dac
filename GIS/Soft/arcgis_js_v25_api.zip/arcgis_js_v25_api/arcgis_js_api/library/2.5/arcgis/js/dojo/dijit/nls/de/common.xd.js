window[esri._dojoScopeName||"dojo"]._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dijit.nls.de.common"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dijit.nls.de.common");dojo._xdLoadFlattenedBundle("dijit", "common", "de", {"buttonOk":"OK","buttonCancel":"Abbrechen","buttonSave":"Speichern","itemClose":"Schließen"});
}};});