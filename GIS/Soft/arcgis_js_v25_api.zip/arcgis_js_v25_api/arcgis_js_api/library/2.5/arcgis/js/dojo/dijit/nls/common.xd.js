window[esri._dojoScopeName||"dojo"]._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dijit.nls.common"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dijit.nls.common");dojo._xdLoadFlattenedBundle("dijit", "common", "", {"buttonOk":"OK","buttonCancel":"Cancel","buttonSave":"Save","itemClose":"Close"});
}};});