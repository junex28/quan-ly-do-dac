window[esri._dojoScopeName||"dojo"]._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dijit.form.nls.tr.validate"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dijit.form.nls.tr.validate");dojo._xdLoadFlattenedBundle("dijit.form", "validate", "tr", {"rangeMessage":"Bu değer aralık dışında.","invalidMessage":"Girilen değer geçersiz.","missingMessage":"Bu değer gerekli."});
}};});