window[esri._dojoScopeName||"dojo"]._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dijit.form.nls.ca.ComboBox"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dijit.form.nls.ca.ComboBox");dojo._xdLoadFlattenedBundle("dijit.form", "ComboBox", "ca", {"previousMessage":"Opcions anteriors","nextMessage":"Més opcions"});
}};});