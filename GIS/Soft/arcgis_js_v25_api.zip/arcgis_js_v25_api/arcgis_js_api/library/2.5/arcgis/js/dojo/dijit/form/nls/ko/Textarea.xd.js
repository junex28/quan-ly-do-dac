window[esri._dojoScopeName||"dojo"]._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dijit.form.nls.ko.Textarea"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dijit.form.nls.ko.Textarea");dojo._xdLoadFlattenedBundle("dijit.form", "Textarea", "ko", {"iframeEditTitle":"편집 영역","iframeFocusTitle":"편집 영역 프레임"});
}};});