window[esri._dojoScopeName||"dojo"]._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dijit.form.nls.el.validate"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dijit.form.nls.el.validate");dojo._xdLoadFlattenedBundle("dijit.form", "validate", "el", {"rangeMessage":"Η τιμή αυτή δεν ανήκει στο εύρος έγκυρων τιμών.","invalidMessage":"Η τιμή που καταχωρήσατε δεν είναι έγκυρη.","missingMessage":"Η τιμή αυτή πρέπει απαραίτητα να καθοριστεί."});
}};});