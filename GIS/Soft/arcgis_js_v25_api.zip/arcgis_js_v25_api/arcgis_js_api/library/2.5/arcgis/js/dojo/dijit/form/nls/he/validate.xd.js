window[esri._dojoScopeName||"dojo"]._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dijit.form.nls.he.validate"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dijit.form.nls.he.validate");dojo._xdLoadFlattenedBundle("dijit.form", "validate", "he", {"rangeMessage":"הערך מחוץ לטווח.","invalidMessage":"הערך שצוין אינו חוקי.","missingMessage":"זהו ערך דרוש."});
}};});