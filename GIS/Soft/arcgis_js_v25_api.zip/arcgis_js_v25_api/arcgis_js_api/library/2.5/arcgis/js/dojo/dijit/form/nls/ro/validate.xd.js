window[esri._dojoScopeName||"dojo"]._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dijit.form.nls.ro.validate"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dijit.form.nls.ro.validate");dojo._xdLoadFlattenedBundle("dijit.form", "validate", "ro", {"rangeMessage":"Această valoare este în afara intervalului. ","invalidMessage":"Valoarea introdusă nu este validă.","missingMessage":"Această valoare este necesară."});
}};});