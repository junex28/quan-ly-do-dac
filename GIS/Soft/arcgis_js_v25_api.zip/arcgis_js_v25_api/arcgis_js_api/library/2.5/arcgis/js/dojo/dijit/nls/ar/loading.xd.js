window[esri._dojoScopeName||"dojo"]._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dijit.nls.ar.loading"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dijit.nls.ar.loading");dojo._xdLoadFlattenedBundle("dijit", "loading", "ar", {"loadingState":"جاري التحميل...","errorState":"عفوا، حدث خطأ"});
}};});