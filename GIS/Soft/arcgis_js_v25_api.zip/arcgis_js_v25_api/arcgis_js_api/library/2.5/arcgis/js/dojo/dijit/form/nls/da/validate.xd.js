window[esri._dojoScopeName||"dojo"]._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dijit.form.nls.da.validate"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dijit.form.nls.da.validate");dojo._xdLoadFlattenedBundle("dijit.form", "validate", "da", {"rangeMessage":"Værdien er uden for intervallet.","invalidMessage":"Den angivne værdi er ikke gyldig.","missingMessage":"Værdien er påkrævet."});
}};});