window[esri._dojoScopeName||"dojo"]._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dijit.form.nls.kk.Textarea"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dijit.form.nls.kk.Textarea");dojo._xdLoadFlattenedBundle("dijit.form", "Textarea", "kk", {"iframeEditTitle":"өңдеу аумағы","iframeFocusTitle":"өңдеу аумағының жақтауы"});
}};});