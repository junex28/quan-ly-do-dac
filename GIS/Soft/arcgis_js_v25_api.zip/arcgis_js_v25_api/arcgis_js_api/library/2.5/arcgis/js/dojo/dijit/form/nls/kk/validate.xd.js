window[esri._dojoScopeName||"dojo"]._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dijit.form.nls.kk.validate"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dijit.form.nls.kk.validate");dojo._xdLoadFlattenedBundle("dijit.form", "validate", "kk", {"rangeMessage":"Бұл мән ауқымнан тыс.","invalidMessage":"Енгізілген мән жарамды емес.","missingMessage":"Бұл мән міндетті."});
}};});