window[esri._dojoScopeName||"dojo"]._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dijit.nls.da.common"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dijit.nls.da.common");dojo._xdLoadFlattenedBundle("dijit", "common", "da", {"buttonOk":"OK","buttonCancel":"Annullér","buttonSave":"Gem","itemClose":"Luk"});
}};});