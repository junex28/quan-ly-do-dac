window[esri._dojoScopeName||"dojo"]._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dijit.form.nls.nl.validate"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dijit.form.nls.nl.validate");dojo._xdLoadFlattenedBundle("dijit.form", "validate", "nl", {"rangeMessage":"Deze waarde is niet toegestaan.","invalidMessage":"De opgegeven waarde is ongeldig.","missingMessage":"Deze waarde is verplicht."});
}};});