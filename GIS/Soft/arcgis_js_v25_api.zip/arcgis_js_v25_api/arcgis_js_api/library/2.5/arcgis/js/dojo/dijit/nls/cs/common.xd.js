window[esri._dojoScopeName||"dojo"]._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dijit.nls.cs.common"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dijit.nls.cs.common");dojo._xdLoadFlattenedBundle("dijit", "common", "cs", {"buttonOk":"OK","buttonCancel":"Storno","buttonSave":"Uložit","itemClose":"Zavřít"});
}};});