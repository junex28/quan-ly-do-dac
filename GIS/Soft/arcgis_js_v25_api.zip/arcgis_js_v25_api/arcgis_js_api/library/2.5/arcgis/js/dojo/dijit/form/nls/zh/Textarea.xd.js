window[esri._dojoScopeName||"dojo"]._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dijit.form.nls.zh.Textarea"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dijit.form.nls.zh.Textarea");dojo._xdLoadFlattenedBundle("dijit.form", "Textarea", "zh", {"iframeEditTitle":"编辑区","iframeFocusTitle":"编辑区框架"});
}};});