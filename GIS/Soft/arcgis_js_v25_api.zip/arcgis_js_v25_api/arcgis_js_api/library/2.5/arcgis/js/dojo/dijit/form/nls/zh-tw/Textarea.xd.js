window[esri._dojoScopeName||"dojo"]._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dijit.form.nls.zh-tw.Textarea"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dijit.form.nls.zh-tw.Textarea");dojo._xdLoadFlattenedBundle("dijit.form", "Textarea", "zh-tw", {"iframeEditTitle":"編輯區","iframeFocusTitle":"編輯區框"});
}};});