window[esri._dojoScopeName||"dojo"]._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dijit.form.nls.ro.Textarea"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dijit.form.nls.ro.Textarea");dojo._xdLoadFlattenedBundle("dijit.form", "Textarea", "ro", {"iframeEditTitle":"zonă de editare","iframeFocusTitle":"cadru zonă de editare"});
}};});