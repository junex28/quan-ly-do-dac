window[esri._dojoScopeName||"dojo"]._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dijit.nls.da.loading"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dijit.nls.da.loading");dojo._xdLoadFlattenedBundle("dijit", "loading", "da", {"loadingState":"Indlæser...","errorState":"Der er opstået en fejl"});
}};});