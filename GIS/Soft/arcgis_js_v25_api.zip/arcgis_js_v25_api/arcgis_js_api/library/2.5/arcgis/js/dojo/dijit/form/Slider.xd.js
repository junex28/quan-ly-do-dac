/*
	Copyright (c) 2004-2011, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/


window[esri._dojoScopeName||"dojo"]._xdResourceLoaded(function(_1,_2,_3){return {depends:[["provide","dijit.form.Slider"],["require","dijit.form.HorizontalSlider"],["require","dijit.form.VerticalSlider"],["require","dijit.form.HorizontalRule"],["require","dijit.form.VerticalRule"],["require","dijit.form.HorizontalRuleLabels"],["require","dijit.form.VerticalRuleLabels"]],defineResource:function(_4,_5,_6){if(!_4._hasResource["dijit.form.Slider"]){_4._hasResource["dijit.form.Slider"]=true;_4.provide("dijit.form.Slider");_4.require("dijit.form.HorizontalSlider");_4.require("dijit.form.VerticalSlider");_4.require("dijit.form.HorizontalRule");_4.require("dijit.form.VerticalRule");_4.require("dijit.form.HorizontalRuleLabels");_4.require("dijit.form.VerticalRuleLabels");_4.deprecated("Call require() for HorizontalSlider / VerticalRule, explicitly rather than 'dijit.form.Slider' itself","","2.0");}}};});