window[esri._dojoScopeName||"dojo"]._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dijit.nls.ca.common"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dijit.nls.ca.common");dojo._xdLoadFlattenedBundle("dijit", "common", "ca", {"buttonOk":"D'acord","buttonCancel":"Cancel·la","buttonSave":"Desa","itemClose":"Tanca"});
}};});