window[esri._dojoScopeName||"dojo"]._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dijit.form.nls.ca.validate"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dijit.form.nls.ca.validate");dojo._xdLoadFlattenedBundle("dijit.form", "validate", "ca", {"rangeMessage":"Aquest valor és fora de l'interval","invalidMessage":"El valor introduït no és vàlid","missingMessage":"Aquest valor és necessari"});
}};});